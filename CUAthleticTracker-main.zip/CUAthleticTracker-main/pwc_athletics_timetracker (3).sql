-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2022 at 08:35 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pwc_athletics_timetracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `co_op`
--

CREATE TABLE `co_op` (
  `User_ID` int(11) NOT NULL DEFAULT 0,
  `Hours_Needed` int(3) NOT NULL DEFAULT 180,
  `Hours_Worked` float(5,2) NOT NULL DEFAULT 0.00,
  `Hours_Remaining` float(5,2) NOT NULL DEFAULT 180.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `co_op`
--

INSERT INTO `co_op` (`User_ID`, `Hours_Needed`, `Hours_Worked`, `Hours_Remaining`) VALUES
(5, 180, 8.00, 172.00),
(6, 160, 20.00, 180.00),
(7, 180, 0.00, 180.00),
(8, 1, 4.00, 177.00),
(9, 1, 1.00, 180.00),
(10, 160, 20.00, 180.00),
(11, 180, 0.00, 180.00),
(12, 180, 0.00, 180.00),
(14, 180, 0.00, 180.00),
(15, 180, 0.00, 180.00),
(16, 180, 8.75, 171.25);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `Event_ID` int(11) NOT NULL,
  `Event_Name` varchar(50) NOT NULL,
  `Event_Date` date NOT NULL,
  `Report_Time` time NOT NULL,
  `Event_Description` varchar(400) NOT NULL DEFAULT '"Event Description"'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`Event_ID`, `Event_Name`, `Event_Date`, `Report_Time`, `Event_Description`) VALUES
(1, 'Swim Meet', '2022-03-03', '08:30:00', '\"Event Description\"'),
(2, 'Please Work', '2022-03-03', '08:30:00', '\"Event Description\"'),
(3, '', '0000-00-00', '00:00:00', '\"Event Description\"'),
(4, 'Soccer Game', '2022-03-15', '20:28:00', 'game of soccer'),
(5, 'Soccer 2', '2022-04-12', '21:43:00', 'Wow soccer'),
(6, 'Login Time', '2022-08-09', '00:21:00', 'Login yay'),
(7, 'Yay I love soccer', '2022-04-11', '22:01:00', 'Soccer ball');

-- --------------------------------------------------------

--
-- Table structure for table `scheduled_events`
--

CREATE TABLE `scheduled_events` (
  `Event_ID` int(100) NOT NULL,
  `User_ID` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `scheduled_events`
--

INSERT INTO `scheduled_events` (`Event_ID`, `User_ID`) VALUES
(1, 5),
(4, 5),
(5, 5),
(4, 5),
(4, 5),
(1, 8),
(5, 9),
(6, 8),
(6, 11),
(6, 15),
(5, 16),
(1, 16),
(7, 8),
(6, 16),
(7, 16);

-- --------------------------------------------------------

--
-- Table structure for table `time_clock`
--

CREATE TABLE `time_clock` (
  `Clock_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Event_ID` int(100) NOT NULL,
  `Clock_In` time NOT NULL,
  `Clock_Out` time DEFAULT NULL,
  `Total_Time` float(4,2) DEFAULT NULL,
  `Punch_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `time_clock`
--

INSERT INTO `time_clock` (`Clock_ID`, `User_ID`, `Event_ID`, `Clock_In`, `Clock_Out`, `Total_Time`, `Punch_Date`) VALUES
(2, 8, 1, '12:00:00', '15:00:00', 3.00, '0000-00-00'),
(3, 5, 1, '12:00:00', '15:00:00', 3.00, '0000-00-00'),
(4, 5, 5, '09:00:00', '14:00:00', 5.00, '0000-00-00'),
(5, 16, 5, '12:00:00', '15:00:00', 3.00, '0000-00-00'),
(6, 16, 1, '07:00:00', '10:00:00', 3.00, '0000-00-00'),
(7, 16, 6, '02:31:05', '02:31:28', 0.01, '2022-03-30'),
(8, 16, 7, '13:30:00', '16:15:00', 2.75, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_ID` int(11) NOT NULL,
  `User_Type` varchar(1) NOT NULL DEFAULT 'C',
  `Username` varchar(30) NOT NULL DEFAULT 's_',
  `Password` varchar(30) NOT NULL,
  `First_Name` varchar(30) NOT NULL DEFAULT 'First Name',
  `Last_Name` varchar(30) NOT NULL DEFAULT 'Last Name',
  `Email` varchar(50) DEFAULT '@eagle.clarion.edu',
  `Phone_Num` varchar(13) NOT NULL DEFAULT '111-222-3333'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_ID`, `User_Type`, `Username`, `Password`, `First_Name`, `Last_Name`, `Email`, `Phone_Num`) VALUES
(5, 'C', 's_kjbranton', 'UWishM8', 'Kyle', 'Branton', 'k.j.branton@eagle.clarion.edu', '7244809304'),
(6, 'C', 's_smRol', 'roleup', 'Ron', 'Don', 'r.s.don@eagle.clarion.edu', '4567891245'),
(7, 'C', 's_MemeMcMeme', 'Meme', 'Meme', 'Mr', 'm.m.m@eagle.clarion.edu', '45678912345'),
(8, 'C', 'k', 'k', 'k', 'k', 'k@gmail.com', '1'),
(9, 'C', 'l', 'l', 'l', 'l', 'l@aol.colm', '1'),
(10, 'A', 'admin', 'admin', 'jody', 'admin', 'af@aol.com', '1234567894'),
(11, 'C', 'r', 'r', 'r', 'r', 'r@aol.com', '3'),
(12, 'C', 'a', 'a', 'a', 'a', 'a@aol.com', '1'),
(14, 'C', 'h', 'h', 'h', 'h', 'h@h', '1'),
(15, 'C', 'U', 'U', 'U', 'U', 'U@aol.com', '1234567894'),
(16, 'C', 'X', 'X', 'X', 'X', 'X@aol.com', '1234567894');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `co_op`
--
ALTER TABLE `co_op`
  ADD PRIMARY KEY (`User_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`Event_ID`),
  ADD UNIQUE KEY `Event_ID` (`Event_ID`),
  ADD KEY `Event_ID_2` (`Event_ID`);

--
-- Indexes for table `scheduled_events`
--
ALTER TABLE `scheduled_events`
  ADD KEY `FK_SchedEvent_Event` (`Event_ID`),
  ADD KEY `FK_SchedEvent_CoOP` (`User_ID`),
  ADD KEY `Event_ID` (`Event_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `time_clock`
--
ALTER TABLE `time_clock`
  ADD PRIMARY KEY (`Clock_ID`),
  ADD KEY `FK_TimeClock_Events` (`Event_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `Event_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `time_clock`
--
ALTER TABLE `time_clock`
  MODIFY `Clock_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `co_op`
--
ALTER TABLE `co_op`
  ADD CONSTRAINT `co_op_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `scheduled_events`
--
ALTER TABLE `scheduled_events`
  ADD CONSTRAINT `scheduled_events_ibfk_1` FOREIGN KEY (`Event_ID`) REFERENCES `events` (`Event_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `scheduled_events_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `co_op` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_clock`
--
ALTER TABLE `time_clock`
  ADD CONSTRAINT `time_clock_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `co_op` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `time_clock_ibfk_2` FOREIGN KEY (`Event_ID`) REFERENCES `scheduled_events` (`Event_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
