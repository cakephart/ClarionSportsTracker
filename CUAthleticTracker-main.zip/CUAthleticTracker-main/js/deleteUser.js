function openUserDeletionForm() {
    document.getElementById("confirmUserDeletion").style.display = "block";
}
/* If by mistake the delete button is clicked, open a confirmation box -- Chandler*/
function closeUserDeletionForm() {
    document.getElementById("confirmUserDeletion").style.display = "none";
}
