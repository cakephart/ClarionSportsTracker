document.getElementById("btnSave").addEventListener("click", handleUpdateUser);

function handleUpdateUser() {

//Array var that holds the data by the variable ID
            var updateUserData={
                User_ID: document.getElementById("userId").value,
                User_Type: document.getElementById("User_Type").value,
                First_Name:  document.getElementById("First_Name").value,
                Last_Name:  document.getElementById("Last_Name").value,
                Email:  document.getElementById("Email").value,
                Phone_Num:  document.getElementById("Phone_Num").value,
                Hours_Needed:  document.getElementById("Hours_Needed").value,
                Hours_Worked:  document.getElementById("Hours_Worked").value,
                Hours_Remaining:  document.getElementById("Hours_Remaining").value

            };
//Ajax calls UpdateUserAccount from the controller (the case, not function), then stringify the updateUserData from updateUserData function in controller
            $.ajax({
                method: "POST",
                url: "../controller/controller.php",
                data:{action: "UpdateUserAccount", updateUserData: JSON.stringify(updateUserData) },
                success: function(data)
                {//alert(data);
                alert("Success");


                }
            });


}

