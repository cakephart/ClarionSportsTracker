//The user needs to be able to click Select so that way they select the event they want to work.
//Pull up a page (The Punch Card) that fetches the event row, populating read only text fields
//The user should be able to clock in on the punch card page

var selectBtnNum = document.getElementById("ScheduledEventsTable").rows.length;

AddSelectEventListeners();

function AddSelectEventListeners()
{
    //For each select button, grab event data
    for (let i=1; i<selectBtnNum; i++)
    {
        document.getElementById("Select"+i).addEventListener("click", handleSelectClick)
    }
}

function handleSelectClick()
{
    for (let i=1; i<selectBtnNum; i++)
    {

        if(event.target.id == "Select" + i)
        {
            var Event_ID = document.getElementById("ScheduledEventsTable").rows[i].cells[1].innerHTML;
            alert(Event_ID);
            $.ajax({
                method: "POST",
                url: "../controller/controller.php",
             /* This action from controller needs to change*/   data:{action: "AllEvents", Event_ID:Event_ID},
                success: function(data)
                {alert(data);

                    window.location.replace("../View/punchCard.php?data="+data);

                }
            });
        }
    }
}