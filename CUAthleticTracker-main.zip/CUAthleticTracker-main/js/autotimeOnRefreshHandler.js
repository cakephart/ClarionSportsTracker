var Event_ID = 0;
var User_ID = 0;
var Punch_Date = 0;
var clockIn = 0;
document.getElementById("btnClockOut").addEventListener("click", ClockOut);
document.getElementById("btnClockOut").addEventListener("click", UpdateTotalHours);
window.onload = function() {
    var autoTimeTable = document.getElementById("hiddenEventClockTable");
    document.getElementById("clockInTime").value = clockIn = autoTimeTable.rows[1].cells[3].innerHTML;
    document.getElementById("start_clock").hidden = false;
    document.getElementById("startTimeHeader").hidden = false;
    document.getElementById("outMessage").hidden = false;
    document.getElementById("btnClockOut").hidden = false;
    document.getElementById("clockInTime").hidden = true;

}
var dtOut;
var outInterval;
// updates clock in time
function updateClockOut() {
    dtOut = new Date();
    document.getElementById("clockOutTime").value = dtOut.toLocaleTimeString('it-IT');
}
outInterval = setInterval(updateClockOut, 500);

function ClockOut(){

    clearInterval(outInterval);
    document.getElementById("btnClockOut").disabled = true;
    outInterval = setInterval(updateClockOut, 500);
    var autoTimeTable = document.getElementById("stupidHiddenEventIdTable");

    Event_ID = autoTimeTable.rows[1].cells[0].innerHTML;
    User_ID = autoTimeTable.rows[1].cells[1].innerHTML;
    clockIn = autoTimeTable.rows[1].cells[3].innerHTML;

    var timeData = {
        userId: User_ID,
        eventId: Event_ID,
        clockIn: clockIn,
        clockOut: document.getElementById("clockOutTime").value};

    $.ajax({
        url:'../controller/controller.php',
        type: 'POST',
        data:{action: "clockout", timeCardData: JSON.stringify(timeData)},
        success: function(data) {
            $('#result').html(data);
        }
    });
}

function DeleteWorkedEvents() {

    clearInterval(outInterval);

    var timeData = {
        userId: User_ID,
        eventId: Event_ID};

    $.ajax({
        url:'../controller/controller.php',
        type: 'POST',
        data:{action: "deleteworkedevents", timeCardData: JSON.stringify(timeData)},
        success: function(data) {
            $('#result').html(data);
            location.reload();

        }
    });
}

function UpdateTotalHours()
{

    var timeData ={
        userId:User_ID,
        taskId:Event_ID
    };

    $.ajax({
        url: '../controller/controller.php',
        type: 'POST',
        data:{action: "updatetotalhours", timeCardData: JSON.stringify(timeData),},
        success: function(data) {
            $('#result').html(data);
        }
    });
    //   $.post( "../controller/adminController.php" );
}




