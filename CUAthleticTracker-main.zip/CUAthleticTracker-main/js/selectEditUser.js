

var editBtnNum = document.getElementById("EditUserTable").rows.length;
var deleteBtnNum = document.getElementById("EditUserTable").rows.length;
    AddEditEventListeners();
function AddEditEventListeners(){
    for (let i=1; i<editBtnNum; i++)
    {
        document.getElementById("Edit"+i).addEventListener("click", handleEditClick)
    }
    for (let i=1; i<deleteBtnNum; i++)
    {
        document.getElementById("Delete"+i).addEventListener("click", handleDeleteClick)
    }
}

function handleEditClick() {


    for (let i=1; i<editBtnNum; i++)
    {

        if(event.target.id == "Edit" + i)
        {

            var User_ID = document.getElementById("EditUserTable").rows[i].cells[1].innerHTML;
            //alert(User_ID);
            $.ajax({
                method: "POST",
                url: "../controller/controller.php",
                data:{action: "AdminEditAccount", User_ID:User_ID},
                success: function(data)
                {alert(data);

                   window.location.replace("../View/adminEditAccount.php?data="+data);

                }
            });
        }
    }
}

function handleDeleteClick() {


    for (let i=1; i<deleteBtnNum; i++)
    {

        if(event.target.id == "Delete" + i)
        {

            var User_ID = document.getElementById("EditUserTable").rows[i].cells[1].innerHTML;

            $.ajax({
                method: "POST",
                url: "../controller/controller.php",
                data:{action: "DeleteUser", userData: JSON.stringify(userData)},
                success: function(data)
                {alert("This user will be deleted now");

                    location.reload();

                }
            });
        }
    }
}
