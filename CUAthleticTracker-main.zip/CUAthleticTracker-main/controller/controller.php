
<?php

session_start();
require_once '../model/model.php';
require_once '../lib/general_Func.php';


if (isset($_POST['action'])) {	    // check get and post
    $action = $_POST['action'];
} else if (isset($_GET['action'])) {
    $action = $_GET['action'];
} else {
    $action = "";	// Default action that guest is authorized to use.
}



    switch ($action) {

        case 'AdminEditAccount':
            if (loggedIn() && isAdmin()) {
            editUser();}
            break;

        case 'UpdateUserAccount':
            updateUserData();
            break;

        case 'AddToSchedule':
            if (loggedIn()) {
            addToSchedule();}
            break;

        case 'AddEvents':
            if (loggedIn() && isAdmin()) {
            addEvents();}
            break;

        case 'AddUser':
            addUser();
            break;

        case 'SelectEventToClockIn':
            if (loggedIn()) {
            include '../view/punchCard.php';}
            break;

        case 'SelectEventUpdateHours':
            if (loggedIn()) {
            include '../view/coOpAddWorkedEvent.php';}
            break;

        case 'AdminHome':
            if (loggedIn() && isAdmin()) {
                include '../view/adminHome.php';
            }
            break;

        case 'AdminManageAccounts':
            if (loggedIn() && isAdmin()) {
            listUsers();}
            break;

        case 'AllEvents':
            if (loggedIn()) {
            allEvents();}
            break;

        case 'AllWorkedEvents':
            if (loggedIn()) {
            allWorkedEvents();}
            break;

        case 'AdminEventsView':
            if (loggedIn() && isAdmin()) {
            eventsViewAdmin();}
            break;

        case 'addWorkedEventsUser':
            if (loggedIn()) {
            addWorkedEventsUser();}
            break;

        case 'CoOpHome':
            if (loggedIn()) {
                include '../view/coOpHome.php';
            }
            break;

        case 'clockIn':
            if (loggedIn()) {
            clockIn();}
            break;

        case 'clockOut':
            if (loggedIn()) {
            clockOut();
            }
            break;

        case 'DisplayScheduledEvents':
            if (loggedIn()) {
            displayScheduledEvents();}
            break;

        case 'DisplayUserSelectedScheduledEvent':
            if (loggedIn()) {
            DisplayUserSelectedScheduledEvent();}
            break;

        case 'displayUserWorkedEvents':
            if (loggedIn()) {
            displayUserWorkedEvents();}
            break;

        case 'DisplayManageUsers':
            if (loggedIn() && isAdmin()) {
            displayManageUsers();}
            break;

        case 'DisplayUsers':
            if (loggedIn()) {
            displayUsers();}
            break;

        case 'DeleteUser':
            if (loggedIn() && isAdmin()) {
            deleteUser();}
            break;

        case 'ScheduledEvents':
            if (loggedIn()) {
            include '../view/coOpScheduledEvents.php';}
            break;



        case 'signUp':
            include '../view/signUp.php';
            break;


        case 'ProcessAddEditEvent':
            if (loggedIn() && isAdmin()) {
            processAddEditEvent();}
            break;
        case 'ProcessAddWorkedEvent':
            if (loggedIn()) {
            processAddWorkedEvent();}
            break;
        case 'processRegisterUser':
            processRegisterUser();
            break;

        case 'ProcessAddEditEvent':
            if (loggedIn() && isAdmin()) {
            processAddEditEvent();}
            break;
        case 'ProcessAddWorkedEvent':
            if (loggedIn()) {
            processAddWorkedEvent();}
            break;
        case 'processRegisterUser':
            processRegisterUser();
            break;

//    case 'displayHoursNeededUser':
//        displayHoursNeededUser();
//        break;
//
//    case 'displayHoursWorkedUser':
//        displayHoursWorkedUser();
//        break;
//
//    case 'displayHoursRemainingUser':
//        displayHoursRemainingUser();
//        break;

    case 'login':
    {
        destroySession();
        include'../view/login.php';
        break;
    }

    default:
        destroySession();
        include'../view/loginError.php';
    }




if (isset($_SESSION['User_Type']))
{
    echo("SESSION ".$_SESSION['User_Type']);
}
function allEvents()
{
    $results = getEvents();
    include '../view/allEvents.php';

}

function destroySession()
{
    setcookie(session_id(), "", time() - 3600);
    session_destroy();
    $_SESSION = array();
    session_write_close();
}
function loggedIn(){
    if ((isset($_SESSION['Username'])))
    {
        return true;
    }
    else{
        return false;
    }
}


function isAdmin(){
    if ($_SESSION['User_Type'] == "admin")
    {
        return true;
    }
    else{
        destroySession();
        header('Location: '.'../controller/controller.php?action=login');


function isAdmin(){
    if ($_SESSION['User_Type'] == "admin")
    {
        return true;
    }
    else{
        destroySession();
        header('Location: '.'../controller/controller.php?action=login');


    }
}
function addToSchedule()
{
    //JAS This is an insert, why are we getting results
    //Hard coded for now to get the event ID and User_ID
    //$results = addScheduledEvents($Event_ID, $User_ID);
    $Event_ID = $_GET['Event_ID'];
    addScheduledEvents($Event_ID,  $_SESSION["User_ID"]);
    include '../view/coOpHome.php';
}

function addEvents()
{
    $mode = "Add";
    $Event_ID = 0;
    $Event_Name = "Name The Event";
    $Event_Date = "";
    $Report_Time = "";
    $Event_Description = "Describe the Event";


    include '../view/addEvents.php';
}

//User needs to be able to add an event they have worked into time_clock INNER JOIN co_op (The user needs to see their hours worked and hours needed)
//Hours remaining is not needed in the DB, Lopez only wanted what they worked and what they need
function addWorkedEventsUser()
{
    $mode = "Add";
    $Clock_ID = 0;
    $Event_Date = "";
    $Clock_In = "";
    $Clock_Out = "";
    $Hours_Worked = "";

    include '../view/coOpAddWorkedEvent.php';
}


function addUser()
{
    $mode = "Add";
    $User_ID = 0;
    $User_Type = 'C';
    $Username = "s_";
    $Password = "";
    $First_Name = "First Name";
    $Last_Name = "Last Name";
    $Email = "@eagle.clarion.edu";
    $Phone_Num = "";
    $Hours_Needed = 180;
    $Hours_Worked = 0;
    $Hours_Remaining = 180;


    include '../view/adminEditAccount.php';
}

//JAS Updated
function clockIn()
{
    $event_id = $_GET['Event_ID'];
    $user_id = $_GET['User_ID'];
    $defaultDate = date_default_timezone_set('US/Eastern');
    $time = $date = date('h:i:s');
    $clockInDate = date("Y-m-d");

    InsertClockIn($event_id, $user_id, $time, $clockInDate);

    echo $time;
    echo $clockInDate;
    echo $date;
    include "../View/clockInSuccessScreen.php ";
    //JAS You should maybe have a page here that has the echo message above with a button to take you
    //to the home page?


}
//Get the total time and clock out.
//JAS Updated
function clockOut(){
    $event_id = $_GET['Event_ID'];
    $user_id = $_GET['User_ID'];
    //Get date and time
    $defaultDate=date_default_timezone_set('US/Eastern');
    $clockOutTime = date('h:i:s');
    $clockInTime = GetClockinTime($event_id, $user_id);

    $start = date_create_from_format('H:i:s', $clockInTime['Clock_In']);
    $end = date_create_from_format('H:i:s', $clockOutTime);
    $hours = round(($end->getTimestamp()-$start->getTimestamp())/(3600),2);
    InsertClockOut($event_id, $user_id, $hours, $clockInTime['Clock_In'], $clockOutTime);


    include "../View/clockOutSuccessScreen.php ";
    //JAS You should maybe have a page here that has the echo message above with a button to take you
    //to the home page?
}

function deleteUser() {
    /*this function will need to go into the model in a security directory when we get that far*/
    $userArr = json_decode($_POST['userData']);
    echo "Processing deletion of user";
    ProcessDeleteUser($userArr);
}

function displayScheduledEvents()
{
    $results = GetUserScheduledEvents( $_SESSION["User_ID"]);
    include '../view/coOpScheduledEvents.php';
}

//Show the user their events worked from their punch card, they have to see it somehow --Chandler
function displayUserWorkedEvents()
{
    $results = getUserPunchCard( $_SESSION["User_ID"]);

    include '../view/coOpWorkedEvents.php';
}

function displayUserTotalHours()
{
    $results= getHoursWorked( $_SESSION["User_ID"]); //User needs to see their total hours somewhere
}

//Fetch ID of the event and UserID student side
function DisplayUserSelectedScheduledEvent()
{

    $event_id = $_GET['EventId'];



    $user_id = $_GET['UserId'];
    // $results=GetUserSelectedScheduledEvent($event_id, $user_id);
    //echo("Results");
    //print_r($results);
    // include '../view/testClockIn.php';
}

// CAK
function displayManageUsers()
{
    $results = getManageUsers();
    include '../view/adminManageAccounts.php';
}

//We need to get the hours needed from the DB and display it as a label on coOpHome --Chandler
function displayHoursNeededUser()
{

    $results = getHoursNeeded();
    include '../view/coOpHome.php';
}

function displayHoursWorkedUser()
{
//This will need changed once a user is signed in. For now, it is hard coded
    $results = getHoursWorked(900, 40);
    include '../view/coOpHome.php';
}

function displayHoursRemainingUser()
{
    $results = getHoursRemaining(900, 20);
    include '../view/coOpHome.php';
}
//-------------------------------------------------------------------------------
function displayUsers()
{
    $results = getAllUsers();
    include '../view/listUsers.php';

}
//Josh needs to do the events part on Admin side
function eventsViewAdmin()
{
    $results = getEvents();
    //This function needs to display all events in a table (inner join events and scheduledevents)
    //Function also needs to populate the text fields with the information (if you want to do it different Josh, you can)
    //Function needs to have checking (if statements) to see is the event checked, if it is, populate the text fields, etc...
    include '../view/adminEventsView.php';
}
function editUser()
{
    $User_ID = $_POST['User_ID'];
    $row = getCoOp($User_ID);
    if ($row == false)
    {
        header("Location: ../view/ErrorPage.php");
        $errorMessage = 'That user was not found';

    }
    else
    {
        // echo json_encode($row);
    }

}

/*list all the users that are in the DB */
function listUsers()
{
    $results = getAllUsers();

    if (count($results) == 0) {
        $errorMessage = "No users found in the database.";
        include '../view/ErrorPage.php';
    }

    else
    {
        include '../View/AdminManageAccounts.php';
    }
}


//This function calculates the Hours Worked and Hours Remaining for a user for ALL events worked
//Lopez will be able to see this on his end too!
function processAddWorkedEvent() {
    $mode = "Add";
    $User_ID = $_GET['User_ID'];
    $Event_ID = $_GET['Event_ID'];
    $Event_Date = $_POST['Event_Date'];
    $Clock_In = $_POST['Clock_In'];
    $Clock_Out= $_POST['Clock_Out'];


    $start = date_create_from_format('H:i:s', $Clock_In);
    $end = date_create_from_format('H:i:s', $Clock_Out);
    $Hours_Worked_For_Event = round(($end->getTimestamp()-$start->getTimestamp())/(3600),2);

    //Get the coop hours worked, hours needed etc
    $Coop_Hours_Info = getCoOpHoursInfo($User_ID);
    $Hours_Remaining = $Coop_Hours_Info['Hours_Remaining'];
    $Hours_Worked = $Coop_Hours_Info['Hours_Worked'];


    //Calculate the new coop hours info
    $New_Hours_Needed = $Hours_Remaining - $Hours_Worked_For_Event;
    $New_Hours_Worked = $Hours_Worked + $Hours_Worked_For_Event;



    // Validations
    $errors = "";
//    if (empty($Event_Date)){
//        $errors .= "\\n* Event_Date is required.";
//    }

    if (empty($Clock_In)) {
        $errors .= "\\n* Clock_In is required.";
    }


    if (empty($Clock_Out)) {
        $errors .= "\\n* Clock_Out is required.";
    }

//    if (empty($Hours_Worked)) {
//        $errors .= "\\n* Hours_Worked is required.";
//    }

    if ($errors != "") {
        include '../view/coOpAddWorkedEvent.php';
    } else{
        if ($mode == "Add") {
            InsertHoursUpdate($Event_ID, $User_ID, $Clock_In,$Clock_Out, $Hours_Worked_For_Event, $Event_Date);
            //Have to do an UPDATE SQL to send the changes into the database
            Update_Coop_Hours($User_ID, $New_Hours_Worked, $New_Hours_Needed);
            if ($Coop_Hours_Info['Hours_Remaining'] < 0)
            {
                $Coop_Hours_Info['Hours_Remaining'] = 0;
            }

        } else {
            //$rowsAffected = updateEvent($User_Type, $Username, $Password, $First_Name, $Last_Name, $Email, $Phone_Num);
        }

        header("Location:../controller/controller.php?action=displayUserWorkedEvents");
    }
}

function processAddEditEvent() {
    $mode = $_POST['Mode'];
    $Event_Name = $_POST['Event_Name'];
    $Event_Date = $_POST['Event_Date'];
    $Report_Time = $_POST['Report_Time'];
    $Event_Description = $_POST['Event_Description'];

    // Validations
    $errors = "";

    if (empty($Event_Name) || strlen($Event_Name) > 30) {
        $errors .= "\\n* Event_Name is required and must be no more than 30 characters.";
    }

    if (empty($Event_Date)){
        $errors .= "\\n* Event_Date is required.";
    }

    if (empty($Report_Time)) {
        $errors .= "\\n* Report_Time is required.";
    }

    if ($errors != "") {
        include '../view/addEditEvents.php';
    } else{
        if ($mode == "Add") {

            $Event_ID = insertEvent($Event_Name, $Event_Date, $Report_Time, $Event_Description);

        } else {
            //$rowsAffected = updateEvent($User_Type, $Username, $Password, $First_Name, $Last_Name, $Email, $Phone_Num);
        }

        header("Location:../controller/controller.php?action=AllEvents");
    }
}

//Sign Up Page Function
//---------------------------------------
function processRegisterUser()
{
    $errors = "";
    // Post Fields ( What you want sent to the actual database, thus posting to the database )
    //---------------------------------------
    if($errors == "")
    {
        $First_Name = $_POST['firstName'];
        $Last_Name = $_POST['lastName'];
        $Email = $_POST['emailStudent'];
        $Phone_Num = $_POST['phoneNumber'];
        $Username = $_POST['userName'];
        $Password = $_POST['passWord'];
        $Hours_Needed = $_POST['hoursNeeded'];
        $Hours_Worked = $_POST['hoursCompleted'];
        if(!isset($_POST["User_ID"])){
            $User_ID = saveUserInfo($First_Name, $Last_Name, $Email, $Phone_Num, $Username, $Password);
            saveUserHoursInfo($User_ID, $Hours_Needed, $Hours_Worked);
        }
     //   include('../View/login.php');
    }
    //---------------------------------------

    //Validations for the sign up process
    //I know there are no valadations here i just wanted to get it working first

    if (empty($Username))
    {
        $errors = "Oops! Looks like you forgot your User Name!";
    }
    else
    {
        if (empty($Password))
        {
            $errors = "Oops! Looks like you forgot your PassWord";
        }
        elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $errors = "You must provide a valid email!";
        }
        elseif (empty($Phone_Num) || strlen($Phone_Num) > 13) {
            $errors .= "\\n* Phone Number is required and must be no more than 13 characters.";
        }
        else
        {
            $User_ID = saveUserInfo($First_Name, $Last_Name, $Email, $Phone_Num, $Username, $Password, $Hours_Needed, $Hours_Worked);

        }
    }
}
//---------------------------------------

function updateUserData(){ //Function that takes in the data from a selected user upon clicking edit, then populate fields. Changing the text field, changes it on the DB
    if (isset($_POST["updateUserData"])){
        $updateUserData = json_decode($_POST["updateUserData"]);
        updateUser($updateUserData -> User_ID,
            $updateUserData -> User_Type,
            $updateUserData->First_Name,
            $updateUserData->Last_Name,
            $updateUserData->Email,
            $updateUserData->Phone_Num,
            $updateUserData->Hours_Needed,
            $updateUserData->Hours_Worked,
            $updateUserData->Hours_Remaining);

    }

}


//Login Page Function Call
//---------------------------------------
function ProcessLogin(){
    $Username = $_POST["Username"];
    $Password = $_POST["Password"];

    if(login($Username,$Password))
    {

        $_SESSION["Username"]=$Username;
        $result = userIsAuthorized($Username);
        if ($result['User_ID']!="")
        {
            $_SESSION["User_ID"]=$result['User_ID'];
        if ($result['User_Type'] =='A')
        {
            $_SESSION['User_Type']="admin";
            header("Location:../controller/controller.php?action=AdminHome");
        }
        else if ($result['User_Type'] =='C')
        {
            $_SESSION['User_Type']="coop";
            header("Location:../controller/controller.php?action=CoOpHome");
        }
        else{
            unset($_SESSION['User_Type']);
        }




        /* if (isset($_REQUEST["RequestedPage"])) {
             header("Location: http://" . $_SERVER['HTTP_HOST'] . $_REQUEST["RequestedPage"]);
         } else {
             header("Location:../controller/controller.php");
         }*/
    } else
    {
        session_destroy();
        $_SESSION = array();
         include('../View/login.php');  // default action


    }
}}
//function ProcessLogOut() {
//    logOut();
 //   if (isset($_REQUEST["RequestedPage"])) {
 //       header("Location:" . $_REQUEST["RequestedPage"]);
 //   } else {
 //       header("Location:../controller/controller.php");
 //   }
//}
//---------------------------------------