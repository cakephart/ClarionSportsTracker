

<?php

function addScheduledEvents($Event_ID, $User_ID)
{

    $db = getDatabaseConnection();
    $query = "INSERT INTO scheduled_events (Event_ID, User_ID)
                VALUES (:Event_ID, :User_ID)";
    $statement = $db->prepare($query);
    $statement->bindValue(':Event_ID', $Event_ID);
    $statement->bindValue(':User_ID', $User_ID);
    $success = $statement->execute();
    $statement->closeCursor();
    if ($success) {;
        return $db->lastInsertId();
    } else {
        logSQLError($statement->errorInfo());  // Log error to debug
    }

}

//function deleteUser($userID) {   /*this function will need to go into the model in a security directory when we get that far*/
//    try{
//        $db = getDatabaseConnection();
//        $query = "DELETE FROM user WHERE User_ID = :userID";
//        $statement = $db->prepare($query);
//        $statement->bindValue(':UserID', $userID);
//        $success = $statement->execute();
//        $statement->closeCursor();
//
//        if ($success) {
//            return $statement->rowCount(); // Number of rows affected
//        } else {
//            logSQLError($statement->errorInfo());  // Log error
//        }
//    } catch (PDOException $ex) {
//        displayDBError($ex->getMessage());
//    }
//}

function getDatabaseConnection()
{
    $dsn  = 'mysql:host=localhost;dbname=pwc_athletics_timetracker';
    $username = 'root';
    $password = '';

    try
    {
        $db = new PDO($dsn, $username, $password);
    }
    catch (Exception $ex) {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
    return $db;
}

//Insert the clock in from server to the database
//JAS Updated
function InsertClockIn($event_id, $user_id, $timestamp, $clockInDate)
{
    try {
        $db = getDatabaseConnection();
        $query = 'INSERT INTO time_clock (User_ID,Event_ID, Clock_In, Clock_Out, Total_Time, Punch_Date)
                    VALUES (:User_ID, :Event_ID, :Clock_In, :Clock_Out, :Total_Time, :Punch_Date)';
        $statement = $db->prepare($query);
        $statement->bindValue(':User_ID',  $user_id);
        $statement->bindValue(':Event_ID', $event_id);
        $statement->bindValue(':Clock_In', $timestamp);
        //The clock out and total time must be null because the user needs to actually work the event first--Chandler
        $statement->bindValue(':Clock_Out', null);
        $statement->bindValue(':Total_Time',null);
        $statement->bindValue(':Punch_Date', $clockInDate);
        $success = $statement->execute();
        $statement->closeCursor();
    }
    catch (Exception $ex)
    {

        $errorMessage = $ex;
        include '../view/errorPage.php';
        die;
    }
}

//We must get all information from co_op so we can do calculations per row of data
function getCoOpHoursInfo($User_ID)
{
    $db = getDatabaseConnection();
    $query = "SELECT * FROM co_op WHERE User_ID=:User_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(":User_ID", $User_ID);
    $statement->execute();
    $results = $statement->fetch();
    $statement->closeCursor();
    return $results;
}

//Used to update the coop table with the total time worked for the semester as well as the hours needed for the rest of the semester
function Update_Coop_Hours($User_ID, $Total_Hours_Worked, $Total_Hours_Remaining)
{
    $db = getDatabaseConnection();
    $query = "UPDATE co_op SET 
                Hours_Worked = :Hours_Worked, Hours_Remaining = :Hours_Remaining
                WHERE User_ID=:User_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(':User_ID', $User_ID);
    $statement->bindValue(':Hours_Worked', $Total_Hours_Worked);
    $statement->bindValue(':Hours_Remaining', $Total_Hours_Remaining);
    $success = $statement->execute();

    $statement->closeCursor();

}

function InsertHoursUpdate($event_id, $user_id, $Clock_In,$Clock_Out, $Hours_Worked_For_Event, $clockInDate)
{
    try {

        $db = getDatabaseConnection();
        $query = 'INSERT INTO time_clock (User_ID,Event_ID, Clock_In, Clock_Out, Total_Time, Punch_Date)
                    VALUES (:User_ID, :Event_ID, :Clock_In, :Clock_Out, :Total_Time, :Punch_Date)';
        $statement = $db->prepare($query);
        $statement->bindValue(':User_ID',  $user_id);
        $statement->bindValue(':Event_ID', $event_id);
        $statement->bindValue(':Clock_In', $Clock_In);
        //The clock out and total time must be null because the user needs to actually work the event first--Chandler
        $statement->bindValue(':Clock_Out', $Clock_Out);
        $statement->bindValue(':Total_Time',$Hours_Worked_For_Event);
        $statement->bindValue(':Punch_Date', $clockInDate);
        $success = $statement->execute();
        $statement->closeCursor();

    }
    catch (Exception $ex)
    {

        $errorMessage = $ex;
        include '../view/errorPage.php';
        die;
    }
}


//JAS Added or updated
//Insert the clock out time into the database
function InsertClockOut($event_id, $user_id, $hours_as_decimal, $clockInTime, $clockOutTime)
{
    try {
        $db = getDatabaseConnection();
        $query = 'UPDATE time_clock SET Clock_Out= :Clock_Out, 
        Total_Time=:Total_Time WHERE User_ID= :User_ID AND Event_ID= :Event_ID AND Clock_In = :Clock_In ';
        $statement = $db->prepare($query);
        $statement->bindValue(':User_ID',  $user_id);
        $statement->bindValue(':Event_ID', $event_id);
        $statement->bindValue(':Clock_In', $clockInTime);
        $statement->bindValue(':Clock_Out', $clockOutTime);
        $statement->bindValue(':Total_Time', $hours_as_decimal );
        $success = $statement->execute();
        $statement->closeCursor();
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        //How could we check to see if a user has already clocked out of the event?
        include '../view/clockInErrorPage.php';
        die;
    }

}
//JAS Added
function GetClockIntime($event_id, $user_id)
{
    $db = getDatabaseConnection();
    $query = "SELECT Clock_In FROM time_clock WHERE User_ID=:User_ID AND Event_ID=:Event_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(":User_ID", $user_id);
    $statement->bindValue(":Event_ID", $event_id);
    $statement->execute();
    $results = $statement->fetch();
    $statement->closeCursor();
    return $results;


}

//JAS Eliminated ProcessUpdateTotalHours -- function was below



function getAllUsers()
{
    try
    {
        $db = getDatabaseConnection();
        $query = "SELECT * FROM user ";
        $statement = $db->prepare($query);
        $statement->execute();
        $results = $statement->fetchAll();
        $statement->closeCursor();
        return $results;
    }
    catch (Exception $ex) {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

function getCoOp($User_ID)
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT u.User_ID, User_Type, First_Name, Last_Name, Email, 
                    Phone_Num, Hours_Needed, Hours_Worked, Hours_Remaining  
                    FROM user u LEFT OUTER JOIN co_op c on u.User_ID = c.User_ID
                    WHERE u.User_ID = :User_ID ";
        $statement = $db->prepare($query);
        $statement->bindValue(":User_ID", $User_ID);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

//Need to show the hours needed on the student page by a label
/*function getHoursNeeded()
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT Hours_Needed, User_ID FROM co_op WHERE User_ID = :User_ID";
        $statement = $db->prepare($query);
        $statement->execute();
       
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}*/


function getHoursWorked($User_ID)
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT SUM(Total_Time) AS totalTimeSum FROM time_clock";
        $statement = $db->prepare($query);
        $statement->execute();
        $statement->bindValue(":User_ID", $User_ID);
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

function getHoursRemaining($user_id , $hours_remaining)
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT Hours_Remaining FROM CoOp
WHERE User_ID = :User_ID , Hours_Remaining = :Hours_Remaining ";
        $statement = $db->prepare($query);
        $statement->execute();
        $statement->bindValue(":User_ID", $user_id);
        $statement->bindValue(":Hours_Remaining", $hours_remaining);
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}
function getEvents()
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT * FROM events";
        $statement = $db->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}


//JAS I think you needed a second function to get all of the scheduled events so then you could select one
//This function was originally saying something to the effect of look for the last inserted ID where there wasn't
//one
function GetUserScheduledEvents($User_ID)
{
    $db = getDatabaseConnection();
    $query = "SELECT e.Event_ID, e.Event_Name, e.Event_Date, e.Report_Time, e.Event_Description, s.User_ID 
                FROM events e INNER JOIN scheduled_events s ON s.Event_ID = e.Event_ID 
                WHERE s.User_ID=:User_ID ";
    $statement = $db->prepare($query);
    $statement->bindValue(":User_ID", $User_ID);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();
    return $result;

    }
//Get user Punch Card, the user needs to see their times and events worked (Lopez wanted that, he wants to see it on his end too)
function getUserPunchCard($User_ID)
{
    $db = getDatabaseConnection();
    $query = "SELECT e.Event_Date, e.Event_Name, t.Clock_In, t.Clock_Out, t.Total_Time, c.Hours_Worked, c.Hours_Needed, c.Hours_Remaining
      FROM time_clock t INNER JOIN co_op c ON t.User_ID = c.User_ID 
        INNER JOIN events e  ON t.Event_ID = e.Event_ID 
        WHERE c.User_ID=:User_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(":User_ID", $User_ID);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();
    return $result;

}
function GetUserSelectedScheduledEvents($Event_ID, $User_ID)
{
    $db = getDatabaseConnection();
    $query = "SELECT events.Event_ID, events.Event_Name, events.Event_Date, events.Report_Time, events.Event_Description, scheduled_events.User_ID FROM events 
        INNER JOIN scheduled_events ON scheduled_events.Event_ID = events.Event_ID WHERE 
        scheduled_events.User_ID=:User_ID AND scheduled_events.Event_ID=:Event_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(":User_ID", $User_ID);
    $statement->bindValue(":Event_ID", $Event_ID);
    $statement->execute();
    $results = $statement->fetchAll();
    $statement->closeCursor();
    return $results;

}

function getScheduledEvents()
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT * FROM scheduled_events";
        $statement = $db->prepare($query);
        $statement->execute();
        $result = $statement->All();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

/*This function gets all users that are within the website. Should show up on AdminManageAccounts*/
function getManageUsers()
{
    try
    {


        $db = getDatabaseConnection();
        $query = "SELECT u.User_ID, User_Type, First_Name, Last_Name, Email, 
                    Phone_Num, Hours_Needed, Hours_Worked, Hours_Remaining  
                    FROM user u LEFT OUTER JOIN co_op c on u.User_ID = c.User_ID"; /*we need to left outer join the Co Op table because that has the student's hours, important*/
        $statement = $db->prepare($query);
        $statement->execute();
        $results = $statement->fetchAll();
        $statement->closeCursor();
        return $results;
    }
    catch (Exception $ex) {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

function getEvent($Event_ID)
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT * FROM events
                     WHERE Event_ID = :Event_ID ";
        $statement = $db->prepare($query);
        /*I think this needs to be :Event_ID not :Event
        $statement->bindValue(":Event", $Event_ID); */
        $statement->bindValue(":Event_ID", $Event_ID);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

function getUser($User_ID)
{
    try{
        $db = getDatabaseConnection();
        $query = "SELECT * FROM user
                     WHERE User_ID = :User_ID ";
        $statement = $db->prepare($query);
        $statement->bindValue(":User_ID", $User_ID);
        $statement->execute();
        $result = $statement->fetch();
        $statement->closeCursor();
        return $result;
    }
    catch (Exception $ex)
    {
        $errorMessage = $ex->getMessage();
        include '../view/errorPage.php';
        die;
    }
}

function insertScheduledEvent($Event_ID, $User_ID) {
$db = getDBConnection();
    $query = 'INSERT INTO scheduled_events (Event_ID, User_ID)
                    VALUES (:Event_ID, :User_ID)';
    $statement = $db->prepare($query);
    $statement->bindValue(':Event_ID', $Event_ID);
    $statement->bindValue(':User_ID', $User_ID);
    $success = $statement->execute();
    $statement->closeCursor();
    }
//Sign Up Page Functions
//-------------------------------------X
function saveUserInfo($First_Name, $Last_Name, $Email, $Phone_Num, $Username, $Password)
{
    $db = getDatabaseConnection();
    $query = 'INSERT INTO user (First_Name,Last_Name, Email, Phone_Num, Username, Password)
                    VALUES (:First_Name, :Last_Name, :Email, :Phone_Num, :Username, :Password)';
    $statement = $db->prepare($query);
    $statement->bindValue(':First_Name', $First_Name);
    $statement->bindValue(':Last_Name', $Last_Name);
    $statement->bindValue(':Email', $Email);
    $statement->bindValue(':Phone_Num', $Phone_Num);
    $statement->bindValue(':Username', $Username);
    $statement->bindValue(':Password', $Password);
    $success = $statement->execute();
    $statement->closeCursor();
    if($success){
        return $db->lastInsertId();
    }

}
function saveUserHoursInfo($User_ID,$Hours_Needed, $Hours_Worked)
{
    $db = getDatabaseConnection();
    $query = 'INSERT INTO co_op (User_ID, Hours_Needed, Hours_Worked)
                    VALUES (:User_ID ,:Hours_Needed , :Hours_Worked)';
    $statement = $db->prepare($query);
    $statement->bindValue(':User_ID', $User_ID);
    $statement->bindValue(':Hours_Needed', $Hours_Needed);
    $statement->bindValue(':Hours_Worked', $Hours_Worked);
    $success = $statement->execute();
    $statement->closeCursor();
}
//-------------------------------------X


function ProcessDeleteUser($userData)
{
    try{
        $db = getDatabaseConnection();
        $query = "DELETE FROM user WHERE (id='$userData->User_ID')";
        $statement = $db->prepare($query);

        $success = $statement->execute();
        $statement->closeCursor();

        if ($success) {
            return $statement->rowCount(); // Number of rows affected
        } else {
            logSQLError($statement->errorInfo());  // Log error
        }
    } catch (PDOException $ex) {
        displayDBError($ex->getMessage());
    }
}

function updateUser($User_ID, $User_Type, $First_Name, $Last_Name, $Email, $Phone_Num, $Hours_Needed, $Hours_Worked, $Hours_Remaining)
{
    $db = getDatabaseConnection();
    $query = "UPDATE user, co_op SET User_Type = :User_Type, First_Name = :First_Name, Last_Name = :Last_Name, Email = :Email, Phone_Num = :Phone_Num, Hours_Needed = :Hours_Needed,
                Hours_Worked = :Hours_Worked, Hours_Remaining = :Hours_Remaining
                WHERE user.User_ID=:User_ID AND user.User_ID = co_op.User_ID";
    $statement = $db->prepare($query);
    $statement->bindValue(':User_ID', $User_ID);
    $statement->bindValue(':User_Type', $User_Type);
    $statement->bindValue(':First_Name', $First_Name);
    $statement->bindValue(':Last_Name', $Last_Name);
    $statement->bindValue(':Email', $Email);
    $statement->bindValue(':Phone_Num', $Phone_Num);
    $statement->bindValue(':Hours_Needed', $Hours_Needed);
    $statement->bindValue(':Hours_Worked', $Hours_Worked);
    $statement->bindValue(':Hours_Remaining', $Hours_Remaining);
    $success = $statement->execute();

    $statement->closeCursor();
    echo($success);
}


function insertEvent($Event_Name, $Event_Date, $Report_Time, $Event_Description)
{
    $db = getDatabaseConnection();
    $query = 'INSERT INTO events (`Event_Name`, `Event_Date`, `Report_Time`, `Event_Description`)
                                VALUES (:Event_Name, :Event_Date, :Event_Time, :Event_Description)';
    $statement = $db->prepare($query);
    $statement->bindValue(':Event_Name', $Event_Name);
    $statement->bindValue(':Event_Date', toMySQLDate($Event_Date));
    $statement->bindValue(':Event_Time', $Report_Time);
    $statement->bindValue(':Event_Description', $Event_Description);
    $success = $statement->execute();
    $statement->closeCursor();
    if($success){
        return $db->lastInsertId();
    }

}





//Login Page Functions
//-------------------------------------X
function validateUser($Username,$Password) {
    try {
        $db = getDatabaseConnection();
        $query = "SELECT Username, Password FROM user where Username = :Username AND Password = :Password";
        $statement = $db->prepare($query);
        $statement->bindValue(':Username', $Username);
        $statement->bindValue(':Password', $Password); //sha1 needed for security
        $statement->execute();
        $result = $statement->fetch();  // Should be zero or one row
        $statement->closeCursor();
        return $result;
    } catch (PDOException $e) {
        //displayError($query . "\n" . $e->getMessage());
    }
}

function login($Username,$Password) {
    $result = validateUser($Username,$Password);
    if($result['Username'] === $Username) // Make sure a User row was returned
    {
        $_SESSION["Username"] = $result['Username'];
        //$_SESSION["User_ID"] = $result['User_ID'];
        return true;
    }
    return false;
}



function logOut() {
    $_SESSION = array();
    session_destroy();

}

function userIsAuthorized($Username) {
        try {
            $db = getDatabaseConnection();
            $query = "SELECT User_Type, User_ID FROM `user` WHERE Username=:Username";
            $statement = $db->prepare($query);
            $statement->bindValue(':Username', $Username);

            $statement->execute();
            $results = $statement->fetch();
            $statement->closeCursor();
           return $results;

        } catch (PDOException $e) {
            echo("Not Authorized");
            //displayError($e->getMessage());
        }


}



//-------------------------------------X

