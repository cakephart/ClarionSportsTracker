<?php
$title = "Clock in Successful";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

<title>You clocked in!</title>

<div class="logincontainer loginborder2" style="margin-top: 20px">
    <?php echo "Event successfully clocked in. Please work the event and remember to clock out!" ?>
<br>
    <br>

</div>