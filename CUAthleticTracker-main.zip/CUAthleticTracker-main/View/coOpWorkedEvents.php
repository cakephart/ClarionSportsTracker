<?php
$title = "Events Worked";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

<!-- <script src="../js/selectMyEvent.js.js" defer></script> -->

<div class="logincontainer loginborder2" style="margin-top: 20px">

    <div>
        <div align="center">
            <h1 class="studentpageName" style="color: #4b91ff; font-size: 20px">Your Worked Events</h1>
        </div>

        <div>

            <table id="WorkedEventsTable" style="border-style: outset; border-color: slategray; border-width: 2px" align="center">
                <thead>
                <tr style="border-bottom-style: dashed; border-width: 5px; border-color: black; font-size: 16px">
                    <th scope="col">Event Name</th>
                    <th scope="col">Event Date</th>
                    <th scope="col">Clocked In</th>
                    <th scope="col">Clocked Out</th>
                    <th scope="col">Total Time</th>
                    <th scope="col">Edit Worked Event</th>
                    <th scope="col">Delete Worked Event</th>

                </tr>
                </thead>
                <tbody>

                <a href="../controller/controller.php?action=displayUserWorkedEvents"></a>

                <?php
                $i=1;
                foreach ($results as $row) {
                    ?>
                    <tr style="font-size: 10px">
                        <td><?php echo htmlspecialchars($row['Event_Name']) ?></td>
                        <td><?php echo htmlspecialchars($row['Event_Date']) ?></td>
                        <td><?php echo htmlspecialchars($row['Clock_In']) ?></td>
                        <td><?php echo htmlspecialchars($row['Clock_Out']) ?></td>
                        <td><?php echo htmlspecialchars($row['Total_Time']) ?></td>
<!--                        This row always updates depending on how many hours the user worked-->
<!--                        <td>--><?php //echo htmlspecialchars($row['Hours_Remaining']) ?><!--</td>-->
                        <td><button id="editWorkedEvent<?php echo $i ?>">Edit</button></td>
                        <td><button id="deleteWorkedEvent<?php echo $i ?>">Delete</button></td>
<!--                        --><?php //$event_id=($row['Event_ID']);
//                        $user_id=($row['User_ID']);?>
<!--                        <td> <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px" type="button" href="../controller/controller.php?action=SelectEventToClockIn&EventId=--><?php //echo($event_id);?><!--&UserId=--><?php //echo ($user_id);?><!--">Select Event</a>-->
                        </td>
                    </tr>
                    <?php $i++;
                }
                ?>
                </tbody>
            </table>

<!--            Show the User how many hours they need for the whole semester-->
            <div class="col loginborder3" style="margin-top: 5px; margin-bottom: 10px; border-color: #4e71ff">
                <h2 style="color: slateblue; text-decoration: underline; font-size: 20px"> Hours I Need For Whole Semester</h2>
                <p class="hoursphpEcho" style="color:  #4e71ff" text="Hours"><?php echo(htmlspecialchars($row['Hours_Needed']))?></p>
            </div>
<!--Show the User their Hours Remaining in a text box. The user sees the total time per row of data, it needs displayed here.-->
<!--For example, I worked 5 hours for cleanup on a day. Then, I worked 3 hours helping setup another day.
    Each row would say that student has 172 hours remaining (They say they have a default of 180 hours)
        Therefore, instead of confusing the student, this will show them where they are at with their internship  *  Chandler-->
                        <div class="col loginborder3" style="margin-top: 5px; margin-bottom: 10px; border-color: #4e71ff">
                                <h2 style="color: slateblue; text-decoration: underline; font-size: 20px"> Hours Remaining (Whole Semester)</h2>
                                <p class="hoursphpEcho" style="color:  #4e71ff" text="Hours"><?php echo(htmlspecialchars($row['Hours_Remaining']))?></p>
                        </div>



                <div align="center">
                    <a href="../controller/Controller.php?action=CoOpHome" type="button" class="btn-block; loginButton" style="margin-top: 15px; margin-bottom: 15px">Return Home</a>
                </div>
        </div>
    </div>