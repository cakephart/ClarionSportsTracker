<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8"> <!-- Setting up the char set -->

    <meta name="viewport" content="width= device-width, intial-scale=1">


    <!--====================================================================================== -->
    <!--====================================================================================== -->
    <!--====================================================================================== -->

    <!--Linking the bootstrap in case the downloaded bootstrap doesnt work -->
    <!-- Latest compiled and minified CSS -->


    <!-- jQuery library -->


    <!-- Popper JS -->


    <!-- Latest compiled JavaScript -->


    <!-- Needed for the picture Slides -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet" href="../css/athleticStyling.css" type="text/css"> <!-- Linking the css sheet to the html page -->
    <link rel="icon" href="../pics/favcon.png" sizes="20x20">

    <script>
        function Alert(EventID)
        {
            alert(EventID); // this is the message in ""
        }
    </script>
    <!--====================================================================================== -->
    <!--====================================================================================== -->
    <!--====================================================================================== -->

    <title>
       <?php echo $title ?>
    </title>
    <meta charset="UTF-8">

    <link rel="stylesheet" type="text/css" href="../css/athleticStyling.css">
   0 <style>
        /* Temp until header include is done */
        body
        {
            background-image: url("../pics/whitebackground.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
        }
    </style>
</head>
<body>
<?php
//session_start();




?>






