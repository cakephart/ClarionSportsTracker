

<?php
$title = "| Admin Event View ";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>




<div class="logincontainer loginborder2 events-list-minor" style="margin-top: 20px" align="center">

    <!--Page Header-->
    <h1 class="loginstyle">Events</h1>
    <!--<a href="../controller/controller.php?action=AdminEventsView">Why Is this here?</a>-->


                <select class="events-list" size="5"  style="border-radius: 10px; margin-bottom: 15px">

                    <?php
                    foreach ($results as $row) {
                    ?>
                <option class="events-list-inner"><?php echo htmlspecialchars($row['Event_Name']) ?></option>
                    <?php } ?>
                </select>


    <div align="center">
        <p class="loginstyle">Event Details</p>


        <label for="EventName">Event Name:</label><br>
        <textarea style="resize: none; font-size: 16px; text-align: center" disabled id="EventName" name="EventName">Wrestling Match
        </textarea>
        <br>

        <label for="EventDate">Date:</label><br>
        <textarea style="resize: none; font-size: 16px; text-align: center" disabled id="EventDate" name="EventDate">2/25/22
        </textarea>
        <br>


        <label for="EventTime">Time:</label><br>
        <textarea style="resize: none; text-align: center; font-size: 16px;" disabled id="EventTime" name="EventTime">3:00 P.M.
        </textarea>
        <br>


        <label for="EventDescription">Event Description:</label><br>
        <textarea style="font-size: 16px; text-align: center" disabled id="EventDescription" name="EventDescription" rows="5" cols="20">Sample text for description
        </textarea>

    </div>

    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../controller/controller.php?action=AddEvents">Add New Event</a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../controller/controller.php?action=CoOpHome">Edit Selected Event</a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../controller/controller.php?action=CoOpHome">Delete Selected Event</a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 15px" type="button" href="../controller/controller.php?action=AdminHome">Admin Home</a>
</div>


