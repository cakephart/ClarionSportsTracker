<?php

$title = "Clock in Error";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

<?php  echo"You tried clocking out of an event already worked"?>