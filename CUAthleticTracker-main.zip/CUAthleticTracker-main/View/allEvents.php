<?php
$title = "| Schedule For An Event |";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>




<div class="logincontainer loginborder2" style="margin-top: 20px">

<div>
    <div align="center">
        <h1 class="studentpageName" style="color: #4b91ff; font-size: 20px">Schedule for an Event</h1>
    </div>

    <div>
    <table style="border-style: outset; border-color: slategray; border-width: 2px" align="center">
        <thead>
        <tr style="border-bottom-style: dashed; border-width: 5px; border-color: black; font-size: 13px; text-align: center">
            <th hidden scope="col">Event Name</th>
            <th scope="col">Event Name</th>
            <th scope="col">Date</th>
            <th scope="col">Report Time</th>
            <th scope="col">Description</th>
            <th scope="col">Sign Up</th>
        </tr>
        </thead>
        <tbody>
            <a href="../controller/controller.php?action=AllEvents"></a>
            <?php
            foreach ($results as $row) {
                ?>

                <tr style="font-size: 10px">
                    <td hidden><?php echo htmlspecialchars($row['Event_ID']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Name']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Date']) ?></td>
                    <td><?php echo htmlspecialchars($row['Report_Time']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Description']) ?></td>
                    <td>
                        <a href="../controller/Controller.php?action=AddToSchedule&Event_ID=<?php echo $row['Event_ID'] ?>" type="button" style="text-align: center;  background-color: #87b7ff; color: white; padding: 14px" class="btn-block loginButton loginsignupText">Add</a>
                    </td>
                </tr>

            <?php } ?>
        </tbody>
    </table>
    </div>
    <div align="center">
    <a href="../controller/Controller.php?action=CoOpHome" type="button" class="btn-block; loginButton" style="margin-top: 15px; margin-bottom: 15px">Return Home</a>
    </div>
</div>
</div>
</body>
</html>
