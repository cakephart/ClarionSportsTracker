<?php
$title = "Admin Manage Accounts";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>
<script src="../js/selectEditUser.js" defer></script>
<!--Create tables for the admin to have some power-->

<h1 style="text-align:center" class="adminTextTop">Admin Manage Accounts</h1>



<!-- Redone Bootstrap Table -->
<table class="adminTable" align="center">
    <thead>
        <tr>
            <th>
               | First Name |
            </th>
            <th>
                Last Name |
            </th>
            <th>
                | Email |
            </th>
            <th>
                | Phone Number |
            </th>
            <th>
                Hours Needed |
            </th>
            <th>
                Hours Completed |
            </th>
            <th>
                Hours Remaining |
            </th>
            <th>
                Edit Student Account |
            </th>
            <th>
                Delete Student Account |
            </th>
        </tr>
    </thead>
    <tbody>
    <a href="../controller/controller.php?action=DisplayManageUsers"></a>
    <?php
    $i = 1;
    foreach ($results as $row) {
        ?>
        <tr>
            <td><?php echo htmlspecialchars($row['First_Name']) ?></td>
            <td><?php echo htmlspecialchars($row['Last_Name']) ?></td>
            <td>
                <a href="mailto: <?php echo htmlspecialchars($row['Email']) ?>"><?php echo htmlspecialchars($row['Email']) ?></a>
            </td>
            <td>
                <a href="tel:+<?php echo htmlspecialchars($row['Phone_Num']) ?>"> <?php echo htmlspecialchars($row['Phone_Num']) ?></a>
            </td>
            <td>
                <?php echo htmlspecialchars($row['Hours_Needed']) ?>
            </td>
<!--            Show Lopez the totalTimeSum that is calculated in the model getHoursWorked      *Chandler -->
            <td><?php echo htmlspecialchars($row['Hours_Worked']) ?></td>
            <td><?php echo htmlspecialchars($row['Hours_Remaining']) ?></td>
            <td><button id="Edit<?php echo $i ?>">Edit</button></td>
            <td><button id="Delete"<?php echo $i ?>">Delete</button></td>
        </tr>
        <?php $i++;
    }
    ?>
    </tbody>
</table>
<a class="btn-block loginButtonSignOut loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px; text-align: center" href="../controller/controller.php?action=login">Admin Home</a>
<a class="btn-block loginButtonSignOut loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px; text-align: center" href="../controller/controller.php?action=login">Sign Out</a>


