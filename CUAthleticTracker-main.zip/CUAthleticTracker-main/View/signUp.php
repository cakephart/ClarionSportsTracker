<?php
$title = "Register User";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>
<div class="loginborder signUpText" style="padding-top: 15px; margin-top: 15px">
<h1 style="text-align: center; color: #3f66ff">Information Required</h1>
<div class="row" style="padding-top: 15px; padding-bottom: 15px">
    <div class="col" align="center">
        <form action="../controller/controller.php?action=processRegisterUser" method="post" style="align-items: center">
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>User Name ......... :</mark> </label> <br>
            <input type="text" name="userName" id="userName" style="margin-bottom: 5px; text-align: center" placeholder="s_kpLameo" required/><br />
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>Password ......... :</mark> </label> <br>
            <input type="password" name="passWord" id="passWord" style="margin-bottom: 5px; text-align: center" placeholder="Password" required/><br />
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>First Name ......... :</mark> </label> <br>
            <input type="text" name="firstName" id="firstName" style="margin-bottom: 5px; text-align: center" placeholder="John" required/><br />
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>Last Name ......... :</mark> </label> <br>
            <input type="text" name="lastName" id="lastName" style="margin-bottom: 5px; text-align: center"  placeholder="Doe" required/><br />
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>Email ......... :</mark> </label> <br>
            <input type="email" name="emailStudent" id="emailStudent" style="margin-bottom: 5px; text-align: center" placeholder="j.s.doe@eagle.clarion.edu" required/><br />
            <label style="margin-bottom: 13px" ><mark><p1 style="color: red">*</p1>Phone Number (No Dashes) ......... :</mark> </label> <br>
            <input type="number" name="phoneNumber" id="phoneNumber" style="margin-bottom: 5px; text-align: center" placeholder="7246543287" required/><br />
            <label style="margin-bottom: 11px" ><mark><p1 style="color: red"></p1>Hour's Needed ......... :</mark> </label> <br>
            <input type="number" name="hoursNeeded" id="hoursNeeded" style="margin-bottom: 5px; text-align: center" placeholder="180" required/><br />
            <label style="margin-bottom: 11px" ><mark><p1 style="color: red"></p1>Hour's Completed ......... :</mark> </label> <br>
            <input type="number" name="hoursCompleted" id="hoursCompleted" style="margin-bottom: 5px; text-align: center" placeholder="0" required/><br />
            <input type="submit"  class="btn-block loginButton0 loginsignupText" style="height: 60px; margin-top: 15px"value="Submit"/> <br>
            <a type="button"  class="btn-block loginButton" href="../controller/controller.php?action=login" style="margin-bottom: 15px; height: 60px; padding-top: 15px">BACK</a>
        </form>
    </div>
</div>
</div>

<?php
require_once '../View/footerInclude.php';
?>