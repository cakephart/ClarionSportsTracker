<?php
    $title = "Error";
    require_once '../view/headerInclude.php';
    require_once '../controller/controller.php';
?>

<!--error that shows up if a function is not doing what it's supposed to-->
<?php
    echo "<h3 class='fontColorWhite uploadFiles'>$errorMessage</h3>"
?>


<?php
    require_once '../view/footerInclude.php';
?>
