<?php
$title = "Login Error";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
header('Location: '.'../controller/controller.php?action=login');

?>
<a href='../controller/controller.php?action=login'>Click to Login Again</a>

