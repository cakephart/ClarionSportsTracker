<?php
require_once '../controller/controller.php';

$title = "Manually Punch Into Event";
require_once '../view/headerInclude.php';
$user_id = $_GET['UserId'];
$event_id = $_GET['EventId'];
?>


<div class="logincontainer loginborder2" style="margin-top: 20px" align="center">

    <h1 style = "color:black"> Punch to Event Manually </h1>
    <form class="formLook" method="post" action="../controller/controller.php?action=ProcessAddWorkedEvent&Event_ID=
            <?php echo($event_id)?>&User_ID=<?php echo($user_id)?>">



        <div class="formRow">
<!--Even though this text field is hidden, we need Event_Date to be stored in the database regardless if it's populated or not -- Chandler-->
<!--            <label style="color: Blue; font-size: 15px" for="name"><span class="">*</span>Event Date:</label><br>-->
            <input type="hidden" name="Event_Date" id="" value=""  size="20" maxlength="30" autocapitalize="on" autofocus placeholder="04/28/2022"/>

        </div>
        <div class="formRow">

            <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Clocked in:</label><br>
            <input type="text" name="Clock_In" id="" required size="20" maxlength="30" autocapitalize="on" autofocus placeholder="Punched in when?"/>

        </div>

        <div class="formRow">

            <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Clocked Out:</label><br>
            <input type="text" name="Clock_Out" id="" value="" required size="20" maxlength="30" autocapitalize="on" autofocus placeholder="Punched Out when?"/>

        </div>


        <div class="formRow">

<!--            <label style="color: Blue; font-size: 15px" for="name"><span class="">*</span>Hours Worked:</label><br>-->
            <input type="hidden" step="any" name="Hours_Worked" id="" value=""  size="" maxlength="30" autocapitalize="on" autofocus placeholder="Worked for x hours"/>

        </div>


        <div class="formRow">
            <input type="submit" style="margin-top: 15px" name="Submit Button" value="Add Worked Event to List">
        </div>

    </form>

    <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px; margin-top: 15px" type="button" href="../controller/controller.php?action=CoOpHome">Home</a>

</div>
