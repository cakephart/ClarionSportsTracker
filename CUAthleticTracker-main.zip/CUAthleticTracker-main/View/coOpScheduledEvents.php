<?php
$title = "Schedule For An Event";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

<!-- <script src="../js/selectMyEvent.js.js" defer></script> -->

<div class="logincontainer loginborder2" style="margin-top: 20px">

    <div>
        <div align="center">
            <h1 class="studentpageName" style="color: #4b91ff; font-size: 20px">Your Scheduled Events</h1>
        </div>

        <div>
            <!--Give the table an id, use it in selectMyEvent.js-->
            <table id="ScheduledEventsTable" style="border-style: outset; border-color: slategray; border-width: 2px" align="center">
                <thead>
                <tr style="border-bottom-style: dashed; border-width: 5px; border-color: black; font-size: 16px">
                    <th scope="col">User ID</th>
                    <th scope="col">Event ID</th>
                    <th scope="col">Event Name</th>
                    <th scope="col">Date</th>
                    <th scope="col">Report Time</th>
                    <th scope="col">Event Description</th>
                    <th scope="col">Manually Punch</th>
                    <th scope="col">Punch In</th>
                </tr>
                </thead>
                <tbody>

                <a href="../controller/controller.php?action=DisplayScheduledEvents"></a>

                <?php
                $i=1;
                foreach ($results as $row) {
                ?>
                <tr style="font-size: 10px">
                    <td><?php echo htmlspecialchars($row['User_ID'])?></td>
                    <td><?php echo htmlspecialchars($row['Event_ID']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Name']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Date']) ?></td>
                    <td><?php echo htmlspecialchars($row['Report_Time']) ?></td>
                    <td><?php echo htmlspecialchars($row['Event_Description']) ?></td>
                    <?php $event_id=($row['Event_ID']);
                    $user_id=($row['User_ID']);?>
                    <td> <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px" type="button" href="../controller/controller.php?action=SelectEventUpdateHours&EventId=<?php echo($event_id);?>&UserId=<?php echo ($user_id);?>">Manual Punch</a>
                    <td> <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px" type="button" href="../controller/controller.php?action=SelectEventToClockIn&EventId=<?php echo($event_id);?>&UserId=<?php echo ($user_id);?>">Punch In</a>
                    </td>
                </tr>
                    <?php $i++;
                }
                ?>
                </tbody>
<!--                <tr style="font-size: 10px">-->

<!--      I commented out your css Kyle. We need a foreach loop to iterate per row, getting each event from the DB              <td>-->
<!--                        <a href="../controller/Controller.php?action=CoOpHome" type="button" style="text-align: center; background-color: #87b7ff; color: white; padding: 10px" class="btn-block loginButton loginsignupText">Clock In</a>-->
<!--                    </td>-->


        <div align="center">
            <a href="../controller/Controller.php?action=CoOpHome" type="button" class="btn-block; loginButton" style="margin-top: 15px; margin-bottom: 15px">Return Home</a>
        </div>
    </div>
</div>
