<?php
$title = "Time Clock for Event";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>
<div class="loginborder" align="center">
<!-- Use javascript to display the time off the server-->
    <script src="../js/timeClock.js" defer></script>

    <h1 style="color: #3f66ff"> Punch Card </h1>
    <!--<a type="submit" class="btn-block; loginButton" id="btnClockIn" style="margin-top: 15px; margin-bottom: 15px">Clock In</a> -->
    <?php $user_id = $_GET['UserId'];
    $event_id = $_GET['EventId']; ?>


    <!--display the time when the button clock in is clicked-->
<!--    <div class="col-5">-->
<!--        <input type="text" readonly style="color: black" id="clockDisplay" >-->
<!--    </div>-->

    <div style="height: 40px" id = "clockDisplay" onload="currentTime()"></div>
    <!--Working clock in-->
    <a class="btn-block loginButton" style="padding: 25px" type="submit" href="../controller/controller.php?action=clockIn&Event_ID=
            <?php echo($event_id)?>&User_ID=<?php echo($user_id)?>">Clock In</a>

    <!--<a type="submit" class="btn-block; loginButton" id="btnClockOut" style="margin-top: 15px; margin-bottom: 15px">Clock Out</a>
-->
    <!-- work clock out-->
    <a class="btn-block loginButton " style="padding: 25px" type="button" href="../controller/controller.php?action=clockOut&Event_ID=
            <?php echo($event_id)?>&User_ID=<?php echo($user_id)?>">Clock Out</a>


    <a type="button"  class="btn-block; loginButton" href="../controller/controller.php?action=CoOpHome" style="margin-top: 15px; margin-bottom: 15px; width: 100px; height: 75px">BACK</a>
</div>
</div>
</div>