
<?php
require_once '../view/headerInclude.php';
$mode = "Edit";
$title = "Admin $mode User Account";
$_POST['action'] = "AdminEditAccount";

$data=json_decode($_GET['data']);
$User_ID=$data->User_ID;
$User_Type  = $data->User_Type;
$First_Name = $data->First_Name;
$Last_Name = $data->Last_Name;
$Email = $data->Email;
$Phone_Num = $data->Phone_Num;
$Hours_Needed = $data->Hours_Needed;
$Hours_Worked = $data->Hours_Worked;
$Hours_Remaining = $data->Hours_Remaining;



?>
<script src="../js/updateEditUser.js" defer></script>
<h1 style="text-align:center">Edit User Account Pennwest University </h1>

<h1><?php echo $mode ?> User:</h1>
<!--<form id="userAccountForm" action="../controller/controller.php?action=ProcessEditUser" method="post" enctype="multipart/form-data"> -->
    <form id="userAccountForm">
    <input id="userId" type="hidden" name="User_ID" value="<?php echo $User_ID ?>" />
    <input type="hidden" name="Mode" value="<?php echo $mode ?>" />
    <div class="formRow">
        <label for="User_Type">Student Type:<span class="required">*</span></label>
        <input id = "User_Type" class="fontBlack" type="text" name="User_Type" id="User_Type" value="<?php echo ($User_Type) ?>" required size="1" maxlength="2" autofocus/>
    </div>
    <div class="formRow">
        <label for="First_Name">First Name:<span class="required">*</span></label>
        <input id = "First_Name" class="fontBlack" type="text" name="First_Name" id="First_Name" value="<?php echo ($First_Name) ?>" required size="30" maxlength="50" />
    </div>
    <div class="formRow">
        <label for="Last_Name">Last Name:<span class="required">*</span></label>
        <input class="fontBlack" type="text" name="Last_Name" id="Last_Name" value="<?php echo ($Last_Name) ?>" required size="20" maxlength="12" />
    </div>

    <div class="formRow">
        <label for="Email">Email:<span class="required">*</span></label>
        <input class="fontBlack" type="text" name="Email" id="Email" value="<?php echo ($Email) ?>" required min="30" max="100" step="any"/>
    </div>
    <div class="formRow">
        <label for="Phone_Num">PhoneNumber:<span class="required">*</span></label>
        <input class="fontBlack" type="text" name="Phone_Num" id="Phone_Num" value="<?php echo ($Phone_Num) ?>" />
    </div>
    <div class="formRow">
        <label for="hoursNeeded">Hours Needed:</label>
        <input class="fontBlack" type="number" name="Hours_Needed" id="Hours_Needed"  value="<?php echo ($Hours_Needed) ?>" />
    </div>

    <div class="formRow">
        <label for="hoursWorked">Hours Worked:</label>
        <input class="fontBlack" type="number" name="Hours_Worked" id="Hours_Worked"  value="<?php echo ($Hours_Worked) ?>" />
    </div>

     <div class="formRow">
        <label for="Hours_Remaining">Hours Remaining:</label>
        <input class="fontBlack" type="number" name="Hours_Remaining" id="Hours_Remaining"  value="<?php echo ($Hours_Remaining) ?>" />
    </div>




</form>

<button id ="btnSave" type="button">Save</button>

<div class="container">
    <button class="signoutbtn">Sign out</button>
</div>

<div class="container">
    <button href="../controller/Controller.php?action=AdminHome" class="signoutbtn">Back to Admin Home</button>
</div>
