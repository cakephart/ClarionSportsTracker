<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/athleticStyling.css">
    <title>View Events Pennwest University Athletics</title>
    <style>
        label {
            display: inline-block;
            width: 300px;
            text-align: right;
            vertical-align: top;
            font-size: 30px;
            color: white;
        }
    </style>
</head>
<body>
<!--Page Header-->
<h1 style="text-align:center">Events</h1>

<!--Button to redirect back to Home-->
<button class="back-button" style="position: center">Back</button>

<!--Event Details labels and text boxes-->
<div style="position: absolute; left: 25%">
    <p style="text-align:center; font-size: 30px; color: white">Event Details</p>
    <hr><br><br>

    <label for="EventName">Event Name:</label>
    <textarea style="resize: none; height: 30px; width: 500px; font-size: 16px" id="EventName" name="EventName">Wrestling Match
        </textarea>

    <br><br>

    <label for="EventDate">Date:</label>
    <textarea style="resize: none; height: 30px; width: 500px; font-size: 16px" id="EventDate" name="EventDate">2/25/22
        </textarea>

    <br><br>

    <label for="EventTime">Time:</label>
    <textarea style="resize: none; height: 30px; width: 500px; font-size: 16px;" id="EventTime" name="EventTime">3:00
        </textarea>

    <br><br>

    <label for="EventDescription">Event Description:</label>
    <textarea style="resize: none; width: 500px; font-size: 16px" id="EventDescription" name="EventDescription" rows="15" cols="50">Sample text for description
        </textarea>

</div>
</div><br>

<!--Buttons for list-box-->
<div class="container">
    <button class="confirm-button" style="position: center">Confirm</button>
</div>

</body>
</html>