<?php
$title = "Your Time Punches";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>
<div>
    <h1 class="centerHeader">Your Time Punches</h1>

    <table class="table table-center" style="width: 100%; height: 40%">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Event</th>
            <th scope="col">Date</th>
            <th scope="col">Clock In Time</th>
            <th scope="col">Clock Out Time</th>
            <th scope="col">Edit Time</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>Swim Meet</td>
            <td>2-14-22</td>
            <td>8:30 A.M</td>
            <td>12:30 P.M</td>
            <td>
                <button type="button">Edit Today's Time</button>
            </td>
        </tr>
        <tr>
            <td>Football Game</td>
            <td>3-3-22</td>
            <td>6:30 P.M</td>
            <td>12:30 A.M</td>
            <td>
                <button type="button">Edit Today's Time</button>
            </td>
        </tr><tr>
            <td>Wrestling Meet</td>
            <td>5-25-22</td>
            <td>11:00 A.M</td>
            <td>2:30 P.M</td>
            <td>
                <button type="button">Edit Today's Time</button>
            </td>
        </tr>

        </tbody>
    </table>
    <a href="../controller/Controller.php?action=CoOpHome><button type="button">Return to Home</button></a>
</div>
</body>
</html>
