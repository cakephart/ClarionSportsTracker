<?php
$title = "Users";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>
    <div class="listForm">
        <h1> List </h1>
        <table style="width:100%" border="2">
            <thead>
            <tr>
                <th>User ID</th>
                <th>User Type</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone Number</th>
            </tr>
            </thead>

            <tbody>
            <a href="../controller/controller.php?action=DisplayUsers">
            <?php
                foreach ($results as $row) {

            ?>

                <tr>
                    <td>
                        <?php echo htmlspecialchars($row['User_ID']) ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['User_Type']) ?></td>
                    <td><?php echo htmlspecialchars($row['First_Name']) ?></td>
                    <td><?php echo htmlspecialchars($row['Last_Name']) ?></td>
                    <td><?php echo htmlspecialchars($row['Email']) ?></td>
                    <td><?php echo htmlspecialchars($row['Phone_Num']) ?></td>
                </tr>

            <?php } ?>
            </tbody>
        </table>
    </div>


<?php
require_once '../view/footerInclude.php';