<?php
$title = "Clock Out Successful";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

<title>You clocked out!</title>

<div class="logincontainer loginborder2" style="margin-top: 20px">
    <?php echo "Event successfully clocked out! Check View Worked Events to see your time stamp" ?>
    <br>
    <br>

</div>