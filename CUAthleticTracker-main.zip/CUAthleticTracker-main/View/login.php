

<?php

$title = "Login";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>


<div class="logincontainer">

    <div class="row" align="center">

        <div class="col loginborder">

            <img src="../pics/clarioneagle.png" alt="da bird" style="height: 270px; width: 270px; padding-top: 50px">

            <div>
                <p class="loginstyle">
                    PennWest Clarion <br> Athletic Tracker
                </p>
                <!--  Login Verification -->
                <!------------------------------------------>
                <!------------------------------------------>
                <form action="../controller/controller.php?action=login" method="post">
                    <input type="text" class="form-control" name="Username" placeholder="Username" value="" required="" style="margin-right: 10px; text-align: center; opacity: 75%; padding: 25px">
                    <input type="password" class="form-control" name="Password" placeholder="Password" value="" required="" style="margin-right: 10px; margin-top: 10px; margin-bottom: 10px; text-align: center; opacity: 75%; padding: 25px">
                    <input type="submit" class="btn-block loginButton0 loginsignupText" style="height: 60px" value="Login"/>
                    <?php
                    if (isset($_GET['LoginFailure'])) {
                        echo '<p/><h4> Invalid Username or Password.  Please try again.</h4>';
                    }
                    ?>
                </form>
                <!------------------------------------------>
                <!------------------------------------------>
            </div>
            <div style="margin-bottom: 10px">

                    <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-top: 15px" type="button" href="../controller/controller.php?action=signUp">Student Sign Up</a>

            </div>

        </div>


    </div>

</div>

<?php
require_once '../View/footerInclude.php';

