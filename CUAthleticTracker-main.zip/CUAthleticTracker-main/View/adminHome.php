
<?php

$title = "Admin Home Pennwest University";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>








<div class="logincontainer loginborder2" style="margin-top: 20px" align="center">

    <img src="../pics/AdminIconPng.png" alt="Admin Icon"  style="height: 270px; width: 270px; padding-top: 50px">

    <h1 class="loginstyle" align="center">Hello Administrator</h1>


    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../controller/controller.php?action=AdminEventsView">Events <br><span style="opacity: 50%">( Add | Edit | Delete )</span></a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../controller/controller.php?action=DisplayManageUsers">Manage Accounts <br><span style="opacity: 50%">( Add | Edit | Delete )</span></a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px" type="button" href="../pdf/Admin%20Manual.pdf" target="_blank">Admin Manual <br><span style="opacity: 50%">( How to use each page )</span></a>
    <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px" type="button" href="../controller/controller.php?action=login">Sign Out</a>








</div>








