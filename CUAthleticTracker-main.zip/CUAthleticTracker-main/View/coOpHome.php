
<?php
$title = "Co-op Home Page";
require_once '../view/headerInclude.php';
require_once '../controller/controller.php';
?>

    <title>Student Home Page</title>

<div class="logincontainer loginborder2" style="margin-top: 20px">

    <div class="row" align="center">

        <div class="col-12">

            <form>
                <div class="studentpageName">
                    <h2 style="color: slateblue; text-decoration: underline; font-size: 20px">Co-op Name</h2>
                    <p class="studentpageNamePHPEcho">Ex. Eric Hennry</p>
                </div>
                <div class="studentpageName">
                    <h2 style="color: slateblue; text-decoration: underline; font-size: 20px">Co-op Username</h2>
                    <p class="studentpageNamePHPEcho">s_eghennry</p>
                </div>
            </form>

        </div>

    </div>
    <div class="row" align="center">


<!--Would we want to show the user how many hours they need on the home page or on the coOpWorkedEvents page?-->
<!--    <div class="col loginborder3" style="margin-top: 10px; margin-bottom: 10px; border-color: #4e71ff">-->
<!--        <h2 style="color: slateblue; text-decoration: underline; font-size: 20px">Hours Remaining</h2>-->
<!--        <p class="hoursphpEcho" style="color:  #4e71ff">--><?php //echo($hours_remaining)?><!--</p>-->
<!--    </div>-->
</div>
    <div class="row" align="center"style="margin: 10px">
        <div class="col">
            <a class="btn-block loginButton3 loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px" href="../controller/controller.php?action=AllEvents">Schedule Event  <br><span style="opacity: 50%">( Schedule / View Events )</span></a>
            <!-- JAS Had to change this to DisplayScheduledEvents because ScheduleEvents just displayed the id and the event -->
            <a class="btn-block loginButton4 loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px" href="../controller/controller.php?action=DisplayScheduledEvents">My Scheduled Event  <br><span style="opacity: 50%">( Clock In / Out )</span></a>

            <a class="btn-block loginButton4 loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px" href="../controller/controller.php?action=displayUserWorkedEvents">View Worked Events<br><span style="opacity: 50%">(Hours Information)</span></a>
            <a class="btn-block loginButton4 loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px" href="../pdf/coOp%20Manual.pdf" target="_blank">User Manual  <br><span style="opacity: 50%">( How to use the application )</span></a>
            <button class="btn-block loginButton2 loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px">Semester Report<br><span style="opacity: 50%">( Create Required Documentation )</span></button>
            <a class="btn-block loginButtonSignOut loginsignupText" type="button" style="padding: 25px; margin-top: 25px; margin-bottom: 25px" href="../controller/controller.php?action=login">Sign Out</a>
        </div>

    </div>

</div>

