
<?php
require_once '../controller/controller.php';

$title = "$mode Event";
require_once '../view/headerInclude.php';


?>



<div class="logincontainer loginborder2" style="margin-top: 20px" align="center">

    <h1 style = "color:black"><?php echo $mode ?> an Event</h1>
    <form class="formLook" method="post" action="../controller/controller.php?action=ProcessAddEditEvent">

        <input type="hidden" name="Event_ID" value="<?php echo $Event_ID ?>" />
        <input type="hidden" name="Mode" value="<?php echo htmlspecialchars($mode) ?>" />

            <div class="formRow">

                <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Event Name:</label><br>
                <input type="text" name="Event_Name" id="" value="<?php echo htmlspecialchars($Event_Name) ?>" required size="20" maxlength="30" autocapitalize="on" autofocus placeholder="Event Name"/>

            </div>
            <div class="formRow">

                <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Event Date:</label><br>
                <input type="date" name="Event_Date" id="" value="<?php echo htmlspecialchars($Event_Date) ?>" required size="20" maxlength="30" autocapitalize="on" autofocus placeholder="04/28/2022"/>

            </div>
            <div class="formRow">

                <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Report Time:</label><br>
                <input type="time" name="Report_Time" id="" value="<?php echo htmlspecialchars($Event_Time) ?>" required size="20" maxlength="30" autocapitalize="on" autofocus placeholder="Event Time"/>

            </div>
            <div class="formRow">

                <label style="color: Blue; font-size: 15px" for="name"><span class="required">*</span>Event Description:</label><br>
                <input type="text" name="Event_Description" id="" value="<?php echo htmlspecialchars($Event_Description) ?>" required size="20" maxlength="100" autocapitalize="on" autofocus placeholder="Event Description"/>

            </div>

            <div class="formRow">
                <input type="submit" style="margin-top: 15px" name="Submit Button" value="Add New Event">
            </div>

    </form>

            <a class="btn-block loginButton loginsignupText" style="padding: 25px; margin-bottom: 25px; margin-top: 15px" type="button" href="../controller/controller.php?action=AdminHome">Home</a>

</div>